﻿using System.Collections.ObjectModel;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.DevTools;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using RestSharp;
using SeleniumExtras.WaitHelpers;

namespace PSBBankScrapper
{
    internal abstract class Program
    {
        private static string? CorpId;
        private static string? UserId;
        private static string? Password;
        private static string? Mobile;
        private static string? Upiid;

        private const string BankUrl = "https://psbomnigateway.onlinepsb.co.in/PSB/#/nliLanding";
        private static readonly string UpiIdStatusURL = "https://91.playludo.app/api/CommonAPI/GetUpiStatus?upiId=" + Upiid;
        private const string SaveTransactionUrl = "https://91.playludo.app/api/CommonAPI/SavebankTransaction";
        private static readonly string UpiIdUpdateUrl = "https://91.playludo.app/api/CommonAPI/UpdateDateBasedOnUpi?upiId=";
        private static readonly string GetCaptchaUrl = "https://91.playludo.app//api/captchareader";

        public static void Main(string[] args)
        {
            getConfig();
            startAgain:
            if (GetBankStatusViaUPIId() != "1")
            {
                log("UPI ID is not active");
                sleep(10);
                goto startAgain;
            }

            var driver = InitBrowser();
            try
            {
                while (true)
                {
                    DateTime currentTime = DateTime.Now;
                    DateTime LoginTime = currentTime.AddMinutes(15);
                    GetTransaction(driver,LoginTime);
                }
            }
            catch (Exception Ex)
            {
                log(Ex.Message);
                LogoutButton(driver);
                driver.Quit();
                sleep(10);
                goto startAgain;
            }
        }

        private static IWebDriver InitBrowser()
        {
            log("Initializing browser...");
            var chromeOptions = new ChromeOptions
            {
                PageLoadStrategy = PageLoadStrategy.Eager
            };

            string currentDirectory = Directory.GetCurrentDirectory();
            log("Current directory: " + currentDirectory);

            chromeOptions.AddArgument("--disable-blink-features");
            chromeOptions.AddArgument("--disable-blink-features=AutomationControlled");
            chromeOptions.AddArgument("--log-level=3");
            chromeOptions.AddArgument("--incognito");

            IWebDriver driver = new ChromeDriver(chromeOptions);
            log("Browser initialized.");
            driver.Manage().Window.Maximize();
            try
            {
                string ReturnStatus = Login(driver); // 1 for success, 2 for failure
                if (ReturnStatus == "1")
                {
                    log("Login Successful");
                    return driver;
                }

                log("Failed to login...");
                log("Closing browser...");
                driver.Quit();
            }
            catch (Exception Ex)
            {
                log("Failed to login...");
                log(Ex.Message);
                log("Closing browser...");
                driver.Quit();
            }

            return driver;
        }

        private static string Login(IWebDriver driver)
        {
            var solvedCaptcha = "";
            try
            {
                log("Logging in...");
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                DateTime currentDateTime = DateTime.Now;
                
                inputUrlAgain:
                
                driver.Navigate().GoToUrl(BankUrl);
                bool Islogin = true;
                while (Islogin)
                {
                    log("Corporate Banking click");
                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[1]/ul/li[3]/a")));
                    driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[1]/ul/li[3]/a"))
                        .Click();
                    
                    log("Login Banking click");
                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[2]/div/div[1]/div[1]/div/div/div[1]/div/div/button[2]")));
                    driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[2]/div/div[1]/div[1]/div/div/div[1]/div/div/button[2]"))
                        .Click();
                    
                    sleep(5);
                    bool correctUrl = checkForBankURL(driver);
                    if (correctUrl != false)
                        goto inputUrlAgain;
                    
                    TypingElement(driver, 10, By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[1]/div/input"), 
                        CorpId, "CorporateId");
                    TypingElement(driver, 10, By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[3]/div/input"), 
                        UserId, "UserName");
                    TypingElement(driver, 10, By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[5]/div/input"), 
                        Password, "Password");
                    
                    inputCaptchaAgain:
                    wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[8]/div[1]/div/canvas")));
                    var imageCaptcha = driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[8]/div[1]/div/canvas"));

                    var elementScreenshot = ((ITakesScreenshot)imageCaptcha).GetScreenshot();

                    const string fileName = "captchaFile";
                    var isSaved = SaveImage(elementScreenshot.AsBase64EncodedString, fileName);
                    if (!isSaved)
                    {
                        return "2";
                    }

                    log("Trying for captcha");
                    solvedCaptcha = CaptchaCodeSolve();

                    if (solvedCaptcha == "1")
                        return "2";

                    log("Captcha code is " + solvedCaptcha);
                    solvedCaptcha = solvedCaptcha.Length > 5 ? solvedCaptcha.Trim().Replace(" ", "") : "123456";

                    TypingElement(driver, 10, By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[7]/div/input"), 
                        solvedCaptcha, "Captcha Input");
                    
                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[3]/div/div/button")));
                    driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[3]/div/div/button"))
                        .Click();
                    sleep(5);
                    bool correctOtp = checkForBankCapctha(driver);
                    if (correctOtp != false)
                        goto inputCaptchaAgain;
                    
                    log("OTP Login");
                    wait.Until(ExpectedConditions.ElementIsVisible(By.Id("otppassword1")));
                    log("button click done");
                    string GetOTP = GetOTPFromAPI(currentDateTime);
                    if (GetOTP.Length != 6)
                        return "2";
                    
                    int otpCount = 1;
                    log("OTP is " + GetOTP);
                    
                    foreach (var otp1 in GetOTP)
                    {
                        TypingElement(driver, 10, By.Id("otppassword"+otpCount.ToString()), otp1.ToString(), "OTP Input");
                        otpCount++;
                    }

                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-login/div[6]/div[4]/div/div/div[2]/button")));
                    driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-login/div[6]/div[4]/div/div/div[2]/button")).Click();
                    
                    sleep(5);
                    
                    // if (IsAlertPresent(driver))
                    // {
                    //     AlertHandle(driver);
                    // }
                    
                    log("Oprative account click...");
                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-dashboard-page/div/div[1]/div/div/div/div/div/div/div[1]/div[1]/div/div[2]/div/div/owl-carousel-o/div/div[1]/owl-stage/div/div/div/div/div/div/div/a")));
                    driver.FindElement(
                        By.XPath("/html/body/app-root/div[1]/app-dashboard-page/div/div[1]/div/div/div/div/div/div/div[1]/div[1]/div/div[2]/div/div/owl-carousel-o/div/div[1]/owl-stage/div/div/div/div/div/div/div/a")).Click();
                
                    sleep(5);
                    //Mouse Over Code
                    log("Mouse Over on Current Account..");
                    IWebElement menuElement = driver.FindElement(
                        By.XPath("/html/body/app-root/div[1]/app-accountpage/div[1]/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div/ul/li[2]"));
                    Actions actions = new Actions(driver);
                    actions.MoveToElement(menuElement).Perform();
                
                    log("More details clicked to get Transaction...");
                    wait.Until(ExpectedConditions.ElementIsVisible(
                        By.XPath("/html/body/app-root/div[1]/app-accountpage/div[1]/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div/ul/li[2]/div[5]/div/button[2]")));
                    driver.FindElement(
                        By.XPath("/html/body/app-root/div[1]/app-accountpage/div[1]/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div/ul/li[2]/div[5]/div/button[2]")).Click();
                    
                    bool isReloved = CheckCaptchResolved(driver);
                    if (!isReloved)
                    {
                        Islogin = false;
                    }
                    else
                    {
                        log("Captcha not resolved. Retrying...");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return "2";
            }
            return "1";
        }

        private static void GetTransaction(IWebDriver driver, DateTime LoginTime)
        {
            getRecentTransaction:
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            List<object> list = new List<object>();
            DateTime currentTime = DateTime.Now;
            if (currentTime != LoginTime)
            {
                if (list == null) throw new ArgumentNullException(nameof(list));
                if (GetBankStatusViaUPIId() != "1")
                {
                    log("Bank is not active");
                    sleep(3);
                    LogoutButton(driver);
                }
                
                sleep(5);
                // if (IsAlertPresent(driver))
                // {
                //     AlertHandle(driver);
                // }
                
                IWebElement element = driver.FindElement(
                    By.XPath("/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[2]/div/div/div/ul/li/div[2]/div/div[1]/h5"));
                string AvlBal = element.Text;
                
                wait.Until(ExpectedConditions.ElementIsVisible(
                    By.XPath("/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[4]/div/div/div/div/div/div[2]/div/ul/li[2]")));
                log("Row visible...");
                
                IWebElement tbl1 = driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[4]/div/div/div/div/div/div[2]/div/ul"));
                ReadOnlyCollection<IWebElement> tableRow = tbl1.FindElements(By.TagName("li"));
                log("Row found...");
                
                int i = tableRow.Count;
                for (int j = 1; j < i; j++)
                {
                    var row = tableRow[j];
                    var cols = row.FindElements(By.TagName("div"));
                    if (cols.Count <= 0) continue;
                    string CreatedDate = cols[0].Text;
                    string Description = cols[3].Text;
                    string Amount = "0";
                    Description = GetTheUTRWithoutUTR(Description);
                    
                    if (cols[5].Text == "DR")
                    {
                        Amount = "-" + cols[7].Text.Replace(" ", "").Replace("₹","");
                    }
                    else
                    {
                        Amount = cols[7].Text.Replace(" ", "").Replace("₹","");
                    }
                
                    Amount = Amount.Replace(",", "");
                    AvlBal = AvlBal.Replace(",", "").Replace("₹ ","");
                    string RefNumber = Description;
                    string AccountBalance = AvlBal;
                    string UPIId = GetUPIId(Description);

                    var values = new
                    {
                        Description,
                        CreatedDate,
                        Amount,
                        RefNumber,
                        AccountBalance,
                        BankName = "PSB - " + UserId,
                        UPIId,
                        BankLoginId = UserId
                    };
                    list.Add(values);
                }
                string json = JsonConvert.SerializeObject(list);
                log(json);
                
                log("Going to refresh the transaction...");
                wait.Until(ExpectedConditions.ElementIsVisible(
                    By.XPath("/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[1]/div/div/div[1]/div[4]/button")));
                driver.FindElement(
                    By.XPath("/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[1]/div/div/div[1]/div[4]/button")).Click();
                
                if (list.Count != 0)
                {
                    SaveTransaction(list);
                    log("Data present");
                }
                goto getRecentTransaction;
            }
            else
            {
                LogoutButton(driver);
            }
        }
        
        private static void SaveTransaction(object TransactionList)
        {
            log("Saving the transaction...");
            string json = JsonConvert.SerializeObject(TransactionList);

            var options = new RestClientOptions(SaveTransactionUrl)
            {
                MaxTimeout = -1,
            };
            var client = new RestClient(options);
            var request = new RestRequest("", Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", json, ParameterType.RequestBody);
            RestResponse response = client.Execute<RestResponse>(request);
            log(response.Content ?? "");
            UpdateUPIDate();
        }
        
        private static void UpdateUPIDate()
        {
            try
            {
                var options = new RestClientOptions(UpiIdUpdateUrl + Upiid)
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);
                var request = new RestRequest("", Method.Get);
                request.AddHeader("Content-Type", "application/json");
                RestResponse response = client.Execute<RestResponse>(request);
                log(response.Content ?? "");
            }
            catch (Exception e)
            {
                log(e.Message);
            }
        }
        
        private static string GetTheUTRWithoutUTR(string description)
        {
            try
            {
                if (description.Contains("UPI"))
                {
                    var split = description.Split('/');
                    var value = split.FirstOrDefault(x => x.Length == 12);
                    if (value != null)
                    {
                        return value + " " + description;
                    }
                    return description;
                }
            }
            catch
            {
                return description;
            }
            return description;
        }

        private static string GetUPIId(string description)
        {
            try
            {
                if (!description.Contains("@")) return "";
                var split = description.Split('/');
                var value = split.FirstOrDefault(x => x.Contains("@"));
                if (value != null)
                {
                    value = value.Replace("From:", "");
                }
                return value;
            }
            catch (Exception ex)
            {
                log(ex.Message);
            }
            return "";
        }

        private static bool SaveImage(string ImgStr, string ImgName)
        {
            if (!Directory.Exists("ScreenShotFolder"))
            {
                Directory.CreateDirectory("ScreenShotFolder");
            }

            string imageName = ImgName + ".jpg";
            string imgPath = Path.Combine("ScreenShotFolder", imageName);
            byte[] imageBytes = Convert.FromBase64String(ImgStr);
            File.WriteAllBytes(imgPath, imageBytes);

            return true;
        }
        
        private static string GetOTPFromAPI(DateTime newDateTime)
        {
            try
            {
                int RetryCount = 0;
                while (RetryCount < 10)
                {
                    sleep(5);
                    log("Trying to get OTP from API.. Attempt " + RetryCount);
                    string OTPAPI = getOTPRequest();
                    if (OTPAPI != "")
                    {
                        var responseData = JsonConvert.DeserializeObject<Dictionary<string, string>>(OTPAPI);
                        log(newDateTime.ToString());
                        if (responseData["ErrorMessage"] != "" && DateTime.Parse(responseData["ErrorMessage"]) > newDateTime)
                        {       
                            if (responseData["ErrorCode"] == "1")
                            {
                                log("OTP received from API " + responseData["Result"]);
                                return responseData["Result"];
                            }
                        }
                        log("Failed to get OTP from API");
                    }
                    RetryCount++;
                }
            }
            catch (Exception e)
            {
                log("Failed to get OTP from API");
            }
            return "1";
        }
        
        private static string getOTPRequest()
        {
            try
            {
                log("OTP 6");
                string OTPurl = "https://91.playludo.app/api/CommonAPI/GetBankPhoneOTPViaUPIId?UpiId=" + CorpId;
                log("Getting OTP...");
                var options = new RestClientOptions(OTPurl)
                {
                    MaxTimeout = -1
                };
                var client = new RestClient(options);
                var request = new RestRequest("", Method.Get);
                log("OTP 7");
                request.AddHeader("Content-Type", "application/json");
                RestResponse response = client.Execute<RestResponse>(request);
                log("OTP 8");
                log(response.Content);
                return response.Content;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return "";
        }
        
        private static string CaptchaCodeSolve()
        {
            try
            {
                log("captcha 1");
                DirectoryInfo di = new DirectoryInfo("ScreenShotFolder/");
                string newImageDir = di.FullName;
                var options = new RestClientOptions(GetCaptchaUrl)
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);
                var request = new RestRequest("", RestSharp.Method.Post);
                request.AddFile("image", newImageDir + "captchaFile.jpg");
                RestResponse response = client.Execute<RestResponse>(request);
                var responseData = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content ?? "");
                log("captcha 2");
                if (responseData["ErrorCode"] == "1")
                    return responseData["ErrorMessage"];
                else
                    return "1";
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "1";
            }
        }
        
        private static void TypingElement(IWebDriver driver, int waitingtimeinsecond, By Selection, string? InputMessage, string message)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(waitingtimeinsecond));
            log("Waiting for " + message + " field...");
            wait.Until(ExpectedConditions.ElementIsVisible(Selection));
            log("Typing " + message + "...");

            driver.FindElement(Selection).Clear();
            driver.FindElement(Selection).SendKeys(InputMessage);
        }
        
        private static string GetBankStatusViaUPIId()
        {
            try
            {
                var options = new RestClientOptions(UpiIdStatusURL + Upiid)
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);
                var request = new RestRequest("", Method.Get);
                RestResponse response = client.Execute<RestResponse>(request);
                var responseData = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content ?? "");
                return responseData != null ? responseData["Result"] : "2";
            }
            catch
            {
                return "2";
            }
        }
        
        private static bool CheckCaptchResolved(OpenQA.Selenium.IWebDriver driver)
        {
            try
            {
                string currenturl = driver.Url;
                if (currenturl.Contains("Incorrect"))
                {
                    log("Captcha Error");
                    return true;
                }

                log("Captcha solved");
                return false;
            }
            catch (Exception e)
            {
                return true;
            }
        }
        
        private static bool checkForBankURL(OpenQA.Selenium.IWebDriver driver)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[1]/div/input"));
                return !element.Displayed;
            }
            catch (NoSuchElementException)
            {
                return true;
            }
            catch (StaleElementReferenceException)
            {
                return true;
            }
        }
        
        private static bool checkForBankCapctha(OpenQA.Selenium.IWebDriver driver)
        {
            try
            {
                IWebElement element = driver.FindElement(By.Id("otppassword1"));
                return !element.Displayed;
            }
            catch (NoSuchElementException)
            {
                return true;
            }
            catch (StaleElementReferenceException)
            {
                return true;
            }
        }
        
        private static void getConfig()
        {
            var configurationBuilder = new ConfigurationBuilder();

            configurationBuilder.AddJsonFile("appsettings.json");
            var configuration = configurationBuilder.Build();
            var appSettingsSection = configuration.GetSection("AppSettings");
            CorpId = appSettingsSection["CorpId"];
            UserId = appSettingsSection["UserName"];
            Password = appSettingsSection["Password"];
            Mobile = appSettingsSection["Mobile"];
            Upiid = appSettingsSection["Upiid"];
        }
        
        static bool IsAlertPresent(IWebDriver driver)
        {
            try
            {
                var elementText = "";
                IWebElement element = driver.FindElement(By.XPath("/html/body/app-root/div[1]/div[10]/div[2]/div/p"));
                elementText = element.Text;
                if(elementText=="Sorry, unable to process your request at this moment. Retry Later.")
                    return true;        // "/html/body/app-root/div[1]/div[10]/div[2]/div/p"  // Sorry, unable to process your request at this moment. Retry Later.
                else if(elementText == "There is some difficulty in processing the request. Please try again later.")
                    return true;
                else
                    return false;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        static void AlertHandle(IWebDriver driver)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/app-root/div[1]/div[10]/div[3]/div/button")));
            driver.FindElement(By.XPath("/html/body/app-root/div[1]/div[10]/div[3]/div/button")).Click();
        }
        
        private static void LogoutButton(IWebDriver driver)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/app-root/div[1]/app-header/header/div/div/div/div[4]/div/ul/li[7]/a")));
                driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-header/header/div/div/div/div[4]/div/ul/li[7]/a")).Click();
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/app-root/div[1]/app-header/div[4]/div/div/div[3]/button[2]")));
                driver.FindElement(By.XPath("/html/body/app-root/div[1]/app-header/div[4]/div/div/div[3]/button[2]")).Click();
                sleep(2);
                driver.Quit();
                log("Logged Out.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        
        private static void log(string Message)
        {
            string PrintMessage = "[" + DateTime.Now.ToString("MMMM dd, yyyy h:mm:ss tt") + " - " + Upiid + "] " + Message;
            Console.WriteLine(PrintMessage);
        }
        private static void sleep(int Second)
        {
            log("Sleeping for " + Second.ToString() + " Seconds....");
            Thread.Sleep(Second * 1000);
        }
    }
}